﻿using TrabajoFinalPOO.Models;
using Xunit;

namespace TrabajoFinalPOO.Tests
{
    public class NominaTests
    {
        // Caso 1: Gerente suma el bono de metas
        [Fact]
        public void Gerente_SumaBonoDeMetas()
        {
            var gerente = new Gerente { Nombre = "Ana", Documento = "1", SalarioBase = 1000000, BonoMetas = 200000 };

            double resultado = gerente.CalcularSalarioFinal();

            Assert.Equal(1200000.0, resultado, 2);
        }

        // Caso 2: Asesor sin ventas recibe solo el salario base
        [Fact]
        public void Asesor_SinVentas_RecibeSalarioBase()
        {
            var asesor = new AsesorComercial { Nombre = "Luis", Documento = "2", SalarioBase = 1500000 };

            double resultado = asesor.CalcularSalarioFinal();

            Assert.Equal(1500000.0, resultado, 2);
        }

        // Caso 3: Asesor suma la comisión de una venta
        [Fact]
        public void Asesor_ConVenta_SumaComision()
        {
            var asesor = new AsesorComercial { Nombre = "Luis", Documento = "2", SalarioBase = 1500000 };
            asesor.Ventas.Add(new Venta { Fecha = DateTime.UtcNow, PrecioVehiculo = 50000000, PorcentajeComision = 4 });

            double resultado = asesor.CalcularSalarioFinal();

            Assert.Equal(3500000.0, resultado, 2);
        }

        // Caso 4: Operativo suma el recargo de las horas extras
        [Fact]
        public void Operativo_ConHorasExtras_SumaRecargo()
        {
            var operativo = new Operativo { Nombre = "Mario", Documento = "3", SalarioBase = 1300000 };
            operativo.HorasExtras.Add(new HoraExtra { Fecha = DateTime.UtcNow, CantidadHoras = 10, Recargo = 8000 });

            double resultado = operativo.CalcularSalarioFinal();

            Assert.Equal(1380000.0, resultado, 2);
        }

        // Caso 5: Operativo sin horas extras recibe solo el salario base
        [Fact]
        public void Operativo_SinHorasExtras_RecibeSalarioBase()
        {
            var operativo = new Operativo { Nombre = "Mario", Documento = "3", SalarioBase = 1300000 };

            double resultado = operativo.CalcularSalarioFinal();

            Assert.Equal(1300000.0, resultado, 2);
        }

        // Caso 6: Polimorfismo, una lista de Empleado con los tres tipos
        [Fact]
        public void Polimorfismo_ListaDeEmpleados_SumaTotal()
        {
            var gerente = new Gerente { Nombre = "Ana", Documento = "1", SalarioBase = 1000000, BonoMetas = 200000 };

            var asesor = new AsesorComercial { Nombre = "Luis", Documento = "2", SalarioBase = 1500000 };
            asesor.Ventas.Add(new Venta { Fecha = DateTime.UtcNow, PrecioVehiculo = 50000000, PorcentajeComision = 4 });

            var operativo = new Operativo { Nombre = "Mario", Documento = "3", SalarioBase = 1300000 };
            operativo.HorasExtras.Add(new HoraExtra { Fecha = DateTime.UtcNow, CantidadHoras = 10, Recargo = 8000 });

            List<Empleado> empleados = new List<Empleado> { gerente, asesor, operativo };

            double total = 0;
            foreach (Empleado e in empleados)
            {
                total += e.CalcularSalarioFinal();   // el método cambia según el tipo
            }

            Assert.Equal(6080000.0, total, 2);
        }
    }
}