﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TrabajoFinalPOO.Migrations
{
    /// <inheritdoc />
    public partial class AgregarMontoMetaPeriodo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "MontoMeta",
                table: "PeriodosDeNomina",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MontoMeta",
                table: "PeriodosDeNomina");
        }
    }
}
