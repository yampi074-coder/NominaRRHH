﻿using Microsoft.EntityFrameworkCore;
using TrabajoFinalPOO.Models;

namespace TrabajoFinalPOO.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

       
        public DbSet<Empleado> Empleados { get; set; }

       
        public DbSet<Gerente> Gerentes { get; set; }
        public DbSet<AsesorComercial> Asesores { get; set; }
        public DbSet<Operativo> Operativos { get; set; }
        public DbSet<Venta> Ventas { get; set; }
        public DbSet<HoraExtra> HorasExtras { get; set; }
        public DbSet<PeriodoDeNomina> PeriodosDeNomina { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
    }
}