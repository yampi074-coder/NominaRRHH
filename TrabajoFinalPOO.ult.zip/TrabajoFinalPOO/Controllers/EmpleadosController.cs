﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrabajoFinalPOO.Data;
using TrabajoFinalPOO.Models;
using Microsoft.AspNetCore.Authorization;

namespace TrabajoFinalPOO.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpleadosController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        // Inyección de dependencias: conectamos el controlador con la base de datos
        public EmpleadosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // 1. POST: Para crear un Gerente de prueba
        [HttpPost("crear-gerente")]
        public async Task<IActionResult> CrearGerente(Gerente gerente)
        {
            _context.Empleados.Add(gerente); // EF Core sabe que debe guardarlo con Discriminator "Gerente"
            await _context.SaveChangesAsync();
            return Ok(new { mensaje = "Gerente creado con éxito en Y&A Luxury Motors" });
        }
        [Authorize(Roles = "Administrador")]
        [HttpGet("calcular-nomina")]
        public async Task<IActionResult> CalcularNomina()
        {
            //Pruebas Unit
            try
            {
                // El Include fuerza a traer las listas de ventas y horas extras de la base de datos
                var empleados = await _context.Empleados
                   .Include(e => (e as AsesorComercial).Ventas)
                   .Include(e => (e as Operativo).HorasExtras)
                   .ToListAsync();
                if (!empleados.Any())
                {
                    return NotFound(new { mensaje = "No se encontraron empleados en la base de datos" });
                }

                var resultado = empleados.Select(e => new
                {
                    id = e.Id,
                    documento = e.Documento,
                    nombre = e.Nombre,
                    cargo = e.GetType().Name,
                    salarioBase = e.SalarioBase,
                    totalAPagar = e.CalcularSalarioFinal()
                });

                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { mensaje = "Error al calcular la nómina", detalle = ex.Message });
            }
        }

        // DELETE: Eliminar un empleado por su ID
        [Authorize(Roles = "Administrador")]
        [HttpDelete("eliminar/{id}")]
        public async Task<IActionResult> EliminarEmpleado(int id)
        {
            try
            {
                // CAMBIO: traemos también las ventas y horas extra del empleado
                var empleado = await _context.Empleados
                    .Include(e => (e as AsesorComercial).Ventas)
                    .Include(e => (e as Operativo).HorasExtras)
                    .FirstOrDefaultAsync(e => e.Id == id);
                if (empleado == null)
                    return NotFound(new { error = "Empleado no encontrado en la base de datos." });

                // CAMBIO: primero se borran los registros hijos (evita el error de llave foránea)
                if (empleado is AsesorComercial asesor)
                    _context.Ventas.RemoveRange(asesor.Ventas);
                if (empleado is Operativo operativo)
                    _context.HorasExtras.RemoveRange(operativo.HorasExtras);

                _context.Empleados.Remove(empleado);
                await _context.SaveChangesAsync();

                return Ok(new { mensaje = $"El empleado {empleado.Nombre} ha sido retirado de Y&A Luxury Motors." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Error al eliminar el empleado", detalle = ex.InnerException?.Message ?? ex.Message });
            }

        }

        //put :actualizar datos CRUD
        [Authorize(Roles = "Administrador")]
        [HttpPut("actualizar/{id}")]
        public async Task<IActionResult> ActualizarEmpleado(int id, [FromBody] EmpleadoUpdateDto dto)
        {
            try
            {
                var empleado = await _context.Empleados.FindAsync(id);
                if (empleado == null)
                    return NotFound(new { error = "empleado no encontrado en la base de datos" });

                empleado.Nombre = dto.Nombre;
                empleado.SalarioBase = dto.SalarioBase;

                await _context.SaveChangesAsync();
                return Ok(new { mensaje = $"Los datos de {empleado.Nombre} han sido actualizado correctamente" });

            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Error al actualizar el empleado", detalle = ex.InnerException?.Message });
            }
        }





        // POST: Para crear un Asesor Comercial con sus ventas
        [HttpPost("crear-asesor")]
        public async Task<IActionResult> CrearAsesor([FromBody] AsesorComercial asesor)
        {
            try
            {
                _context.Empleados.Add(asesor);
                await _context.SaveChangesAsync();
                return Ok(new { mensaje = "Asesor Comercial registrado con éxito en Y&A Luxury Motors" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { mensaje = "Error al registrar el Asesor Comercial", detalle = ex.Message });
            }
        }

        // POST: Para crear un Operativo con sus horas extras
        [HttpPost("crear-operativo")]
        public async Task<IActionResult> CrearOperativo([FromBody] Operativo operativo)
        {
            try
            {
                if (operativo == null)
                {
                    return BadRequest(new { mensaje = "Los Datos del personal operativo estan vacios" });
                }
                _context.Empleados.Add(operativo);
                await _context.SaveChangesAsync();
                return Ok(new { mensaje = "Personal Operativo registrado con éxito en Y&A Luxury Motors" });
            }

            catch (Exception ex)
            {
                return StatusCode(500, new { mensaje = "Error al registrar el Personal Operativo", detalle = ex.Message });
            }
        }
    }

    public class EmpleadoUpdateDto
    {
        public string Nombre { get; set; } = string.Empty;
        public double SalarioBase { get; set; }
    }
}