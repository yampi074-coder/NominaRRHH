﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrabajoFinalPOO.Data;
using TrabajoFinalPOO.Models;

namespace TrabajoFinalPOO.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PeriodosNominaController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public PeriodosNominaController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: Configurar la meta de un nuevo mes
        [HttpPost("configurar-meta")]
        public async Task<IActionResult> ConfigurarMeta([FromBody] PeriodoDeNomina periodo)
        {
            try
            {
                _context.PeriodosDeNomina.Add(periodo);
                await _context.SaveChangesAsync();
                return Ok(new { mensaje = $"Meta del mes {periodo.Mes}/{periodo.Anio} registrada correctamente." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Error al guardar la meta", detalle = ex.InnerException?.Message ?? ex.Message });
            }
        }

        // GET: Consultar el historial de metas
        [HttpGet("historial")]
        public async Task<IActionResult> ObtenerHistorial()
        {
            var historial = await _context.PeriodosDeNomina.ToListAsync();
            return Ok(historial);
        }
    }
}