﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using TrabajoFinalPOO.Data;
using TrabajoFinalPOO.Models;

namespace TrabajoFinalPOO.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _config;

        public AuthController(ApplicationDbContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        // POST: Registrar un nuevo usuario del sistema
        [HttpPost("registrar")]
        public async Task<IActionResult> Registrar([FromBody] Usuario nuevoUsuario)//async es para que la operación de guardar en la base de datos sea asíncrona y no bloquee el hilo principal
        {//frombody es para que el objeto usuario se reciba en el cuerpo de la solicitud HTTP
            try
            {
                if (await _context.Usuarios.AnyAsync(u => u.Email == nuevoUsuario.Email))
                    return BadRequest(new { error = "El correo ya está registrado." });

                _context.Usuarios.Add(nuevoUsuario);
                await _context.SaveChangesAsync();

                return Ok(new { mensaje = "Usuario registrado exitosamente." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Error al registrar el usuario", detalle = ex.Message });
            }
        }

        // POST: Iniciar sesión y obtener el token JWT
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Usuario login)
        {
            // Busca al usuario en la base de datos
            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.Email == login.Email && u.PasswordHash == login.PasswordHash);

            if (usuario == null)
                return Unauthorized(new { error = "Correo o contraseña incorrectos." });

            // Si existe, le fabricamos su Token de acceso
            var jwtSettings = _config.GetSection("Jwt");
            var key = Encoding.ASCII.GetBytes(jwtSettings["Key"]!);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Email, usuario.Email),
                    new Claim(ClaimTypes.Role, usuario.Rol) // Aquí guardamos si es Administrador o Asesor
                }),
                Expires = DateTime.UtcNow.AddHours(2), // El token dura 2 horas
                Issuer = jwtSettings["Issuer"],
                Audience = jwtSettings["Audience"],
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return Ok(new
            {
                token = tokenHandler.WriteToken(token),
                mensaje = $"Bienvenido {usuario.Rol}"
            });
        }
    }
}