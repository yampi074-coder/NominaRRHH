﻿namespace TrabajoFinalPOO.Models
{
    public abstract class Empleado
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Documento { get; set; }
        public double SalarioBase { get; set; }
        public abstract double CalcularSalarioFinal();
    }
}