﻿using System.ComponentModel.DataAnnotations;
//para la autenticación de usuarios y roles, se crea la clase Usuario que representa a un usuario en el sistema.
//Esta clase contiene propiedades para almacenar información relevante sobre el usuario, como su correo electrónico,
//contraseña y rol dentro del sistema.
//La propiedad Id es una clave primaria que identifica de manera única a cada usuario.
namespace TrabajoFinalPOO.Models
{
    public class Usuario
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        [Required]
        public string Rol { get; set; } = string.Empty; // Aquí guardaremos "Administrador", "Asesor" u "Operativo"
    }
}