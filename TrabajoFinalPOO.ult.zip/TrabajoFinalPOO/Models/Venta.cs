﻿using System;

namespace TrabajoFinalPOO.Models
{
    public class Venta
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public double PrecioVehiculo { get; set; }
        public double PorcentajeComision { get; set; }
        public double Comision => PrecioVehiculo * (PorcentajeComision / 100);
    }
}