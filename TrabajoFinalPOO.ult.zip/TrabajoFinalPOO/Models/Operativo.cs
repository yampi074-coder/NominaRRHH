﻿using System.Collections.Generic;
using System.Linq;

namespace TrabajoFinalPOO.Models
{
    public class Operativo : Empleado
    {
     
        public List<HoraExtra> HorasExtras { get; set; } = new List<HoraExtra>();

        public override double CalcularSalarioFinal()
        {
            
            double totalExtras = HorasExtras.Sum(h => h.TotalRecargo);

            return SalarioBase + totalExtras;
        }
    }
}