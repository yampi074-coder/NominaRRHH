﻿using System.Collections.Generic;
using System.Linq;

namespace TrabajoFinalPOO.Models
{
    public class AsesorComercial : Empleado
    {
        
        public List<Venta> Ventas { get; set; } = new List<Venta>();

      
        public override double CalcularSalarioFinal()
        {
           
            double totalComisiones = Ventas.Sum(v => v.Comision);

            return SalarioBase + totalComisiones;
        }
    }
}