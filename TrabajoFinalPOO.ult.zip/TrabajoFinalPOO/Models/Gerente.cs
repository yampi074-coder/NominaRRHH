﻿namespace TrabajoFinalPOO.Models
{
   
    public class Gerente : Empleado
    {
        public double BonoMetas { get; set; }

        
        public override double CalcularSalarioFinal()
        {
            return SalarioBase + BonoMetas;
        }
    }
}