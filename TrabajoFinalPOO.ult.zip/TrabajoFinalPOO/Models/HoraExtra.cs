﻿using System;

namespace TrabajoFinalPOO.Models
{
    public class HoraExtra
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int CantidadHoras { get; set; }
        public double Recargo { get; set; } 
        public double TotalRecargo => CantidadHoras * Recargo;
    }
}