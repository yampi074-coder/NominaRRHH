﻿using System.ComponentModel.DataAnnotations;

namespace TrabajoFinalPOO.Models
{
    public class PeriodoDeNomina
    {
        [Key]
        public int Id { get; set; }
        public int Mes { get; set; }
        public int Anio { get; set; }
        public double MontoMeta { get; set; } // El objetivo financiero en dinero
        public bool MetaGlobalAlcanzada { get; set; }
    }
}